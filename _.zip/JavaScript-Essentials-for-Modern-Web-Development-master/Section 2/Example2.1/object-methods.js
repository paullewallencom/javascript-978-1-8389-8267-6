const runStat = {
    distance: 10.2,
    time: {
        hours: 0,
        minutes: 54,
        seconds: 32
    },
    calories: 590
};

console.log(Object.keys(runStat));
console.log(Object.keys(runStat.time));
console.log(Object.values(runStat.time));
console.log(Object.entries(runStat.time));