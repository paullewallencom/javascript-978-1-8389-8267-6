"use strict";

var myVar = "this is a string";

console.log(myVar);

myVar = 28;

console.log(myVar);

myVar = 3.14;

console.log(myVar);

myVar = {
    a: 1,
    b: 2
};

console.log(myVar);
