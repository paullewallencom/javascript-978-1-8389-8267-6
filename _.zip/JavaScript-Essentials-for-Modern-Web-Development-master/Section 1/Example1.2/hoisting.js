(function() {
    "use strict";

    a = 2;
    b = 3;
    printThem();

    var a;
    var b;

    function printThem() {
        console.log(a, b);
    }
})();