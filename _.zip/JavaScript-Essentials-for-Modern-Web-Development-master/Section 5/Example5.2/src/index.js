const FakePersonGenerator = require("./fake-person-generator");

(function() {
    console.log("here's a random person: ");
    console.log(FakePersonGenerator());
})();