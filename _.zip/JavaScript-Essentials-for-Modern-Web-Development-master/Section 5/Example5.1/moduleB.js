console.log("THIS RUNS ONLY ONCE");

module.exports = {
    B: function() {
        console.log("This is B");
    },
    C: function() {
        console.log("This is C");
    }
}