module.exports = function A() {
    console.log("This is A");
}