const A = require("./moduleA");
const B = require("./moduleB").B;
const C = require("./moduleB").C;

A();
B();
C();