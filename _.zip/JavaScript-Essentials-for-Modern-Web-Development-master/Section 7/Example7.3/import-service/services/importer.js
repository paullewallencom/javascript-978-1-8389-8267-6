module.exports = class Importer {
    async import(users) {
        
    }
}