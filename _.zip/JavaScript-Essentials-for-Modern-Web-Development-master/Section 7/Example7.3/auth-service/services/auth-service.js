module.exports = class AuthService {
    async signUp(user) {
        // TODO: Implement
    }

    async signIn(email, password) {
        // TODO: Implement
    }
}